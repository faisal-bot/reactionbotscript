///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
##
PHP Script Bot Reaction 
##
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
##
No Need Username and Password because work with Access Token only but not work with Graph API Explorer Access Token APP. 

Use this Access Token APP "Facebook for iPhone" it's work!

##
<pre>
Support Type: 
LIKE,LOVE,HAHA,WOW,SAD,ANGRY
</pre>
##
<pre>
How to Use?: 
reaction.php?type=(TYPE REACTION)&token=(YOUR ACCESS TOKEN)
</pre>
##
<pre>
Example: 
http://127.0.0.1/reaction.php?type=HAHA&token=EAAAAAYsX7TsBAgaHpfsYad7xehpUsXbOcfD0bZAbjFdMnaW47nqm...
Result:
Content ID : 100011400276720_622574058132598 [SUCCESS] Reacted // Script by FADXPL017
Content ID : 100022361084703_156831831738852 [SUCCESS] Reacted // Script by FADXPL017
Content ID : 100005295270270_763198163866686 [SUCCESS] Reacted // Script by FADXPL017
Content ID : 100022361084703_156830498405652 [SUCCESS] Reacted // Script by FADXPL017
Content ID : 100021897593283_171250506948201 [SUCCESS] Reacted // Script by FADXPL017
Content ID : 100007254768805_1966272020291271 [SUCCESS] Reacted // Script by FADXPL017
Content ID : 100009589936741_1963360997326879 [SUCCESS] Reacted // Script by FADXPL017
Content ID : 100007871438828_1969744636631232 [SUCCESS] Reacted // Script by FADXPL017
Content ID : 100009589936741_1963359380660374 [SUCCESS] Reacted // Script by FADXPL017
Content ID : 206763943191477_238670726667465 [SUCCESS] Reacted // Script by FADXPL017
Content ID : 100006113237937_2017522815128140 [SUCCESS] Reacted // Script by FADXPL017
Content ID : 100017659176138_171497273448911 [SUCCESS] Reacted // Script by FADXPL017
Content ID : 100009166088815_1899531590362359 [SUCCESS] Reacted // Script by FADXPL017
Content ID : 100008973551885_1725931917715910 [SUCCESS] Reacted // Script by FADXPL017
Content ID : 100005295270270_763193970533772 [SUCCESS] Reacted // Script by FADXPL017
</pre>
##


